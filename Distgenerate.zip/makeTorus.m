clear; clc


dh = 0.1;
R=3; r=1;
d = 0.96; c = 0.95;
%fd=@(p) (sum(p.^2,2)+R^2-r^2).^2-4*R^2*(p(:,1).^2+p(:,2).^2);
fd=@(p) ((d^2 + p(:,1).^2 + p(:,2).^2 + p(:,3).^2).^3 - 8*d*d*(p(:,2).^2+p(:,3).^2)-c^4);
figure(1); clf;
[p,t]=distmeshsurface(fd,@fh,dh,(4)*[-1.1,-1.1,-1.1;1.1,1.1,1.1]);


%% Figure by using trimesh (Only surface points)
figure(2);clf;
h = trimesh(t,p(:,1), p(:,2), p(:,3));
set(h,'facecolor','none','edgecolor','k');
axis equal
alpha(0.1)
hold on

%% compute h_ave
lengths=[];
for i=1:length(t)
    a=t(i,1);
    b=t(i,2);
    c=t(i,3);
    A(i)=norm(p(a,:)-p(b,:));
    B(i)=norm(p(b,:)-p(c,:));
    C(i)=norm(p(c,:)-p(a,:));
    ave(i)=[A(i)+B(i)+C(i)];
    lengths=[lengths ave(i)];
end
ave_a=sum(sum(lengths))/(3*length(t));
%% Circulate Ordering points p and t
ss = sprintf('D:/HanWord/vring_data.m');
fid = fopen(ss,'wt');
ss = sprintf('D:/HanWord/DataNumberTriangle.m');
fid2 = fopen(ss,'wt');
for commonPT = 1:1:size(p,1)
    IndexN = find(t(:)==commonPT);
    PT = zeros(length(IndexN),2);
    for i=1:length(IndexN)
        if mod(IndexN(i),size(t,1))==0
            tmpT = t(size(t,1),:);
        else
            tmpT = t(mod(IndexN(i),size(t,1)),:);
        end
        
        if tmpT(1) == commonPT
            PT(i,:) = [tmpT(2) tmpT(3)];
        elseif tmpT(2) == commonPT
            PT(i,:) = [tmpT(3) tmpT(1)];
        else
            PT(i,:) = [tmpT(1) tmpT(2)];
        end
    end
    V=[];
    V(1:2)=PT(1,:);
    PT(1,:)=[];
    for k=1:length(IndexN)-1
        a=find(PT(:,1)==V(end));
        V(end+1)=PT(a,2);
        PT(a,:)=[];
    end
    V(end+1:8)=0;
    fprintf(fid,'%d %d %d %d %d %d %d %d %d \n',length(IndexN), V);
    fprintf(fid2,'%d \n',length(IndexN));
end

fclose(fid);
fclose(fid2);
D = load('D:/HanWord/vring_data.m');

if max(D(:,1))>7
    error happen
end

fidP = fopen(sprintf('D:/HanWord/P_data.m'),'wt');
for i = 1:length(P)
    fprintf(fidP,'%f %f %f\n',p(i,1), p(i,2), p(i,3));
end
fclose(fidP);

fidT = fopen(sprintf('D:/HanWord/T_data.m'),'wt');
for i = 1:length(t)
    fprintf(fidT,'%d %d %d\n',t(i,1), t(i,2), t(i,3));
end
fclose(fidT);

