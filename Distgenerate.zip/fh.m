function h=fh(p)
h1=4*sqrt(sum(p.^2,2))-1;
h=min(h1,2);
% h = zeros(size(p,1));
h = ones(size(p,1),1);

