function d = fd(p)
r = sqrt(p(:,1).^2 + p(:,2).^2);
z = p(:,3);

% d1 = r - 1;
% d2 = z - 2;
% d3 = -z;
% d4 = sqrt(d1.^2+d2.^2);
% d5 = sqrt(d1.^2+d3.^2);
d6 = -1 + sqrt((p(:,1)).^2+(p(:,2)).^2+(p(:,3)).^2);
% d  = max(max(d1,d2),d3);
% ix = d1>0 & d2>0;
% d(ix)=d4(ix);
% ix = d1>0 & d3>0;
% d(ix)=d5(ix);

% d = min(d,d6);
d = d6;
% dsphere = 1 - sqrt(p(:,1).^2+p(:,2).^2+p(:,3).^2);
% d=max(d,-dsphere);